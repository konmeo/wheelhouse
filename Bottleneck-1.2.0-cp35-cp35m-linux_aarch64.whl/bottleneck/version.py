"Bottleneck version"

# Format expected by setup.py and doc/source/conf.py: string of form "X.Y.Z"
__version__ = "1.2.0"
